export { YourWebComponent } from './src/your-webcomponent';
